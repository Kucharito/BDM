from ethereum import Ethereum

class Wallet(Ethereum):
    def __init__(self, web3_provider_url, private_key):
        super().__init__(web3_provider_url)
        # TODO 5: Initialize account using private key
        
        raise NotImplementedError("Please implement this method")

    def get_balance(self):
        balance = self.web3.eth.get_balance(self.account.address)
        return self.web3.from_wei(balance, 'ether')

    def send_transaction(self, to_address, value, gas=21000, gas_price=50):
        # TODO 6: Send transaction and return transaction hash

        raise NotImplementedError("Please implement this method")
    
        return tx_hash.hex()
