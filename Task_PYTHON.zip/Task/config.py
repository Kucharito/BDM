import os

class Config:
    def __init__(self, default_alchemy_url_mainnet=None,
                 default_alchemy_url_sepolia=None,
                 default_private_key=None):
        
        if default_alchemy_url_mainnet is None and os.getenv('ALCHEMY_URL_MAINNET') is None:
            raise ValueError("Default URL for mainnet is not set.")
        if default_alchemy_url_sepolia is None and os.getenv('ALCHEMY_URL_SEPOLIA') is None:
            raise ValueError("Default URL for Sepolia is not set.")
        if default_private_key is None and os.getenv('PRIVATE_KEY') is None:
            raise ValueError("Default private key is not set.")

        self._alchemy_url_mainnet = os.getenv('ALCHEMY_URL_MAINNET', default_alchemy_url_mainnet)
        self._alchemy_url_sepolia = os.getenv('ALCHEMY_URL_SEPOLIA', default_alchemy_url_sepolia)
        self._private_key = os.getenv('PRIVATE_KEY', default_private_key)

    @property
    def alchemy_url_mainnet(self):
        return self._alchemy_url_mainnet

    @property
    def alchemy_url_sepolia(self):
        return self._alchemy_url_sepolia
    
    @property
    def private_key(self):
        return self._private_key
