from web3 import Web3

class Ethereum:
    def __init__(self, web3_provider_url):
        # TODO 1: Initialize Web3 instance
        raise NotImplementedError("Please implement this method")
        
        if not self.web3.is_connected():
            raise Exception("Nepodařilo se připojit k Ethereum síti.")

    def get_block_info(self, block_number='latest'):
        # TODO 2: Get block info
        raise NotImplementedError("Please implement this method")

    def get_transaction_details(self, transaction_hash):
        # TODO 3: Get transaction details
        raise NotImplementedError("Please implement this method")

    def get_current_block_number(self):
        # TODO 4: Get current block number
        raise NotImplementedError("Please implement this method")
